package board;

public class Board {
	
	String title;
	String story;
	String writer;
	String pwd;
	
	
	public Board(String title, String story, String writer, String pwd) {
		super();
		this.title = title;
		this.story = story;
		this.writer = writer;
		this.pwd = pwd;
	}

}
